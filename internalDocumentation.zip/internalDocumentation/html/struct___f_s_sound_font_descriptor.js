var struct___f_s_sound_font_descriptor =
[
    [ "_FSSoundFontDescriptor", "struct___f_s_sound_font_descriptor.html#a894d3a069bc649b012cdafc59bb2093c", null ],
    [ "~_FSSoundFontDescriptor", "struct___f_s_sound_font_descriptor.html#a9f3deb3f726de95603f5fb2324f501e2", null ],
    [ "isFullyInitialized", "struct___f_s_sound_font_descriptor.html#ae78bddbd9d1b929f116b28e63d693c80", null ],
    [ "soundFont", "struct___f_s_sound_font_descriptor.html#a201c5aedb3c85a5b4a44222ec20ca125", null ],
    [ "soundFontMake", "struct___f_s_sound_font_descriptor.html#a09030c2bdf77cc1dd188b2855f6f6f9b", null ],
    [ "soundFontName", "struct___f_s_sound_font_descriptor.html#aaaa8ce91335ef9a4b0a864a0c3462f62", null ],
    [ "soundFontNextPresetInEnumeration", "struct___f_s_sound_font_descriptor.html#af64d634eb148c6afab00a3a078a07018", null ],
    [ "soundFontPresetBankNum", "struct___f_s_sound_font_descriptor.html#a1b18781e4773b19d79335462e8681cde", null ],
    [ "soundFontPresetName", "struct___f_s_sound_font_descriptor.html#a076a2bb1ef453841846b938e97410f4e", null ],
    [ "soundFontPresetProgNum", "struct___f_s_sound_font_descriptor.html#a799cd478005b47c5f9ad8f44e5130918", null ],
    [ "soundFontPresetQuery", "struct___f_s_sound_font_descriptor.html#a17165a426b2433229344bedcc3207d72", null ],
    [ "soundFontResetPresetEnumeration", "struct___f_s_sound_font_descriptor.html#a1789b3b2fd0f74973f25ae0def18e40a", null ]
];