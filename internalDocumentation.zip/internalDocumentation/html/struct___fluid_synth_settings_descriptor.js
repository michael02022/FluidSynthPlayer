var struct___fluid_synth_settings_descriptor =
[
    [ "_FluidSynthSettingsDescriptor", "struct___fluid_synth_settings_descriptor.html#ae2be5381b85a6022793c84d6fb8a3c74", null ],
    [ "~_FluidSynthSettingsDescriptor", "struct___fluid_synth_settings_descriptor.html#a07d7159c16ef812b3b0e31fa87d4b718", null ],
    [ "settings", "struct___fluid_synth_settings_descriptor.html#a154792c07382aff58024e780580c82cb", null ],
    [ "settingsDestroy", "struct___fluid_synth_settings_descriptor.html#a454c1e7335b36abacfa408a6336cc5f0", null ],
    [ "settingsMake", "struct___fluid_synth_settings_descriptor.html#ae008910a3136b6fdd29664f8b23ecce1", null ],
    [ "settingsSetInt", "struct___fluid_synth_settings_descriptor.html#af46acc829f9d678ae937b432c443ea4b", null ],
    [ "settingsSetNum", "struct___fluid_synth_settings_descriptor.html#a57f5d67cd564d76e414492fc72e542cf", null ],
    [ "settingsSetStr", "struct___fluid_synth_settings_descriptor.html#a91207787d922150e0ecdcce0c2f22e7c", null ]
];