var struct___fluid_synth_descriptor =
[
    [ "_FluidSynthDescriptor", "struct___fluid_synth_descriptor.html#a77a5c7239a970ea6a7dd8a4bffacc263", null ],
    [ "~_FluidSynthDescriptor", "struct___fluid_synth_descriptor.html#a6cc4dcaf4f1ad21ba3dc12d72c32abee", null ],
    [ "fluidSynthVersion", "struct___fluid_synth_descriptor.html#a6ee89356c95b0ee6b4b2c28d0072ceff", null ],
    [ "library", "struct___fluid_synth_descriptor.html#afacadcc8d70227edeff9538fdb63b39e", null ]
];