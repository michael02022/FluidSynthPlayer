var searchData=
[
  ['newlinestring_0',['newlineString',['../struct_base_modules_1_1_string_util.html#a24d32ab0738d93d563d72b301a69f3f5',1,'BaseModules::StringUtil::newlineString'],['../struct_string_util.html#a24d32ab0738d93d563d72b301a69f3f5',1,'StringUtil::newlineString']]],
  ['noteoff_1',['noteOff',['../struct_m_i_d_i_1_1_midi_event_kind.html#ae46edf3d52aba98e3a83b067222cdeae',1,'MIDI::MidiEventKind::noteOff'],['../struct_midi_event_kind.html#ae46edf3d52aba98e3a83b067222cdeae',1,'MidiEventKind::noteOff']]],
  ['noteon_2',['noteOn',['../struct_m_i_d_i_1_1_midi_event_kind.html#a8df6e8aea944e824fbbf3ef832551b0a',1,'MIDI::MidiEventKind::noteOn'],['../struct_midi_event_kind.html#a8df6e8aea944e824fbbf3ef832551b0a',1,'MidiEventKind::noteOn']]]
];
