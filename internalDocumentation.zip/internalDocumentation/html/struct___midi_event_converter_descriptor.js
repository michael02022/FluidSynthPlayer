var struct___midi_event_converter_descriptor =
[
    [ "_MidiEventConverterDescriptor", "struct___midi_event_converter_descriptor.html#aadbd733a8f5d79fb4e632581d38728d7", null ],
    [ "_MidiEventConverterDescriptor", "struct___midi_event_converter_descriptor.html#abe9eb7458990cfefeb6e73d32bbdeb08", null ],
    [ "~_MidiEventConverterDescriptor", "struct___midi_event_converter_descriptor.html#a586334675a83252157810a4e8feecb0b", null ],
    [ "handlePresetChange", "struct___midi_event_converter_descriptor.html#a1e48dc36e025de748aa70fb4bc949272", null ],
    [ "handleSoundFontChange", "struct___midi_event_converter_descriptor.html#a47f8965e5eb95829f05607685e478f0e", null ],
    [ "operator=", "struct___midi_event_converter_descriptor.html#a89f0e376e6b1a04d164a0e4102398c34", null ],
    [ "processMidiEvent", "struct___midi_event_converter_descriptor.html#afe1fb02481bb2057b6c475a724d1b15e", null ],
    [ "processMidiEventList", "struct___midi_event_converter_descriptor.html#a3aa29c04ee54e28f6ef7527c9c608a80", null ],
    [ "resetSettings", "struct___midi_event_converter_descriptor.html#a5afd9738bed70514dee0cf35fa014f46", null ],
    [ "setSetting", "struct___midi_event_converter_descriptor.html#a067e456e9d0a6772240f2c129f0b2401", null ],
    [ "settingsKeyToDefaultValueMap", "struct___midi_event_converter_descriptor.html#ad7e15be95dc263e774f30804155500d0", null ],
    [ "_audioIsSuppressedForBadSettings", "struct___midi_event_converter_descriptor.html#ac9b3436c1a8d7a003e4bd49283272734", null ],
    [ "_hasValidPreset", "struct___midi_event_converter_descriptor.html#a0b8dbdfcee273e6e03f64b40f904c16e", null ],
    [ "_library", "struct___midi_event_converter_descriptor.html#acbd53c520ccc00b22960552cd14ea50c", null ],
    [ "_settings", "struct___midi_event_converter_descriptor.html#abadda2b4545d0d7dd00f83a80b41aeef", null ],
    [ "presetName", "struct___midi_event_converter_descriptor.html#a5255d5d3c60494425184d637f80f3a49", null ],
    [ "processingIsInRealtime", "struct___midi_event_converter_descriptor.html#ae6fc03624e7cfbaffe65b402157bdf23", null ],
    [ "settingsDictionary", "struct___midi_event_converter_descriptor.html#a203f3ddf24acc54f08945e34aadab433", null ],
    [ "soundFontIsOkay", "struct___midi_event_converter_descriptor.html#a0006ac5caefa71972518dbc441adc3e2", null ],
    [ "synthesizer", "struct___midi_event_converter_descriptor.html#a51de84447834e0eafc71f293f268a350", null ],
    [ "synthesizerBufferSize", "struct___midi_event_converter_descriptor.html#a09fdb9ea53f512792ab6b7b58d4a7d20", null ]
];