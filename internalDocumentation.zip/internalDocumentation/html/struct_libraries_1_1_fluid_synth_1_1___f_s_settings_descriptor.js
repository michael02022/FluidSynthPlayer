var struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor =
[
    [ "_FSSettingsDescriptor", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html#aef35fe464566a10d97a8137ca8ea67b6", null ],
    [ "~_FSSettingsDescriptor", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html#a1e8032fcafbe9a79661aec35e8279ac4", null ],
    [ "settings", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html#a0eed7ca0d86f08123ff8b64cfa4f490d", null ],
    [ "settingsDestroy", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html#acab65270ebc73be35f754b41ab72592d", null ],
    [ "settingsMake", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html#a1f61d1867fdb08fe4839e4d7a42b6f7a", null ],
    [ "settingsSetInt", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html#a40ae6bf636465b5b4ed2c4f12027f5b9", null ],
    [ "settingsSetNum", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html#aff1df87bb6021430ad3d4bc471565258", null ],
    [ "settingsSetStr", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html#a3203947aa2cac3c605a7a84ca6a8fe23", null ]
];