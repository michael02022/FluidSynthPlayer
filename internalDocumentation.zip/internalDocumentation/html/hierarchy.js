var hierarchy =
[
    [ "_EditorDescriptor", "struct___editor_descriptor.html", null ],
    [ "Main::FluidSynthPlugin::_EditorDescriptor", "struct_main_1_1_fluid_synth_plugin_1_1___editor_descriptor.html", null ],
    [ "_EventProcessorDescriptor", "struct___event_processor_descriptor.html", null ],
    [ "Main::FluidSynthPlugin::_EventProcessorDescriptor", "struct_main_1_1_fluid_synth_plugin_1_1___event_processor_descriptor.html", null ],
    [ "_EventTime", "struct___event_time.html", null ],
    [ "_FluidSynthDescriptor", "struct___fluid_synth_descriptor.html", null ],
    [ "Libraries::FluidSynth::_FluidSynthDescriptor", "struct_libraries_1_1_fluid_synth_1_1___fluid_synth_descriptor.html", null ],
    [ "_FSSettingsDescriptor", "struct___f_s_settings_descriptor.html", null ],
    [ "Libraries::FluidSynth::_FSSettingsDescriptor", "struct_libraries_1_1_fluid_synth_1_1___f_s_settings_descriptor.html", null ],
    [ "_FSSoundFontDescriptor", "struct___f_s_sound_font_descriptor.html", null ],
    [ "Libraries::FluidSynth::_FSSoundFontDescriptor", "struct_libraries_1_1_fluid_synth_1_1___f_s_sound_font_descriptor.html", null ],
    [ "_FSSynthesizerDescriptor", "struct___f_s_synthesizer_descriptor.html", null ],
    [ "Libraries::FluidSynth::_FSSynthesizerDescriptor", "struct_libraries_1_1_fluid_synth_1_1___f_s_synthesizer_descriptor.html", null ],
    [ "_LoggingBufferEntry", "struct___logging_buffer_entry.html", null ],
    [ "BaseModules::_LoggingBufferEntry", "struct_base_modules_1_1___logging_buffer_entry.html", null ],
    [ "_LoggingTime", "class___logging_time.html", null ],
    [ "BaseModules::_LoggingTime", "class_base_modules_1_1___logging_time.html", null ],
    [ "_MidiEventConverterDescriptor", "struct___midi_event_converter_descriptor.html", null ],
    [ "MIDI::_MidiEventConverterDescriptor", "struct_m_i_d_i_1_1___midi_event_converter_descriptor.html", null ],
    [ "_MidiEventDescriptor", "struct___midi_event_descriptor.html", null ],
    [ "MIDI::_MidiEventDescriptor", "struct_m_i_d_i_1_1___midi_event_descriptor.html", null ],
    [ "_RingBuffer", "struct___ring_buffer.html", null ],
    [ "Main::FluidSynthPlugin::_RingBuffer", "struct_main_1_1_fluid_synth_plugin_1_1___ring_buffer.html", null ],
    [ "Audio::AudioDataPointFifoQueue", "struct_audio_1_1_audio_data_point_fifo_queue.html", null ],
    [ "AudioDataPointFifoQueue", "struct_audio_data_point_fifo_queue.html", null ],
    [ "juce::AudioProcessor", null, [
      [ "Main::FluidSynthPlugin::FluidSynthPlugin_EventProcessor", "struct_main_1_1_fluid_synth_plugin_1_1_fluid_synth_plugin___event_processor.html", null ]
    ] ],
    [ "juce::AudioProcessorEditor", null, [
      [ "Main::FluidSynthPlugin::FluidSynthPlugin_Editor", "struct_main_1_1_fluid_synth_plugin_1_1_fluid_synth_plugin___editor.html", null ]
    ] ],
    [ "BaseTypes::Primitives::Boolean", "struct_base_types_1_1_primitives_1_1_boolean.html", null ],
    [ "Boolean", "struct_boolean.html", null ],
    [ "BuildInformation", "struct_build_information.html", null ],
    [ "Main::BuildInformation", "struct_main_1_1_build_information.html", null ],
    [ "BaseModules::CommandLineArgument", "struct_base_modules_1_1_command_line_argument.html", null ],
    [ "CommandLineArgument", "struct_command_line_argument.html", null ],
    [ "BaseModules::CommandLineArgumentHandler", "struct_base_modules_1_1_command_line_argument_handler.html", null ],
    [ "CommandLineArgumentHandler", "struct_command_line_argument_handler.html", null ],
    [ "juce::Component", null, [
      [ "Main::FluidSynthPlugin::_PresetSelectionComponent", "struct_main_1_1_fluid_synth_plugin_1_1___preset_selection_component.html", null ]
    ] ],
    [ "BaseModules::Configuration", "struct_base_modules_1_1_configuration.html", null ],
    [ "Configuration", "struct_configuration.html", null ],
    [ "ConverterProgram", "struct_converter_program.html", null ],
    [ "Main::FluidSynthFileConverter::ConverterProgram", "struct_main_1_1_fluid_synth_file_converter_1_1_converter_program.html", null ],
    [ "DynamicLibrary", "struct_dynamic_library.html", null ],
    [ "Libraries::DynamicLibrary", "struct_libraries_1_1_dynamic_library.html", null ],
    [ "BaseModules::Environment", "struct_base_modules_1_1_environment.html", null ],
    [ "Environment", "struct_environment.html", null ],
    [ "BaseModules::File", "struct_base_modules_1_1_file.html", null ],
    [ "File", "struct_file.html", null ],
    [ "juce::FileDragAndDropTarget", null, [
      [ "Main::FluidSynthPlugin::FluidSynthPlugin_Editor", "struct_main_1_1_fluid_synth_plugin_1_1_fluid_synth_plugin___editor.html", null ]
    ] ],
    [ "FluidSynth", "struct_fluid_synth.html", null ],
    [ "Libraries::FluidSynth::FluidSynth", "struct_libraries_1_1_fluid_synth_1_1_fluid_synth.html", null ],
    [ "FluidSynthPlugin_EditorSupport", "struct_fluid_synth_plugin___editor_support.html", null ],
    [ "Main::FluidSynthPlugin::FluidSynthPlugin_EditorSupport", "struct_main_1_1_fluid_synth_plugin_1_1_fluid_synth_plugin___editor_support.html", null ],
    [ "FluidSynthSettings", "struct_fluid_synth_settings.html", null ],
    [ "Libraries::FluidSynth::FluidSynthSettings", "struct_libraries_1_1_fluid_synth_1_1_fluid_synth_settings.html", null ],
    [ "FluidSynthSoundFont", "struct_fluid_synth_sound_font.html", null ],
    [ "Libraries::FluidSynth::FluidSynthSoundFont", "struct_libraries_1_1_fluid_synth_1_1_fluid_synth_sound_font.html", null ],
    [ "FluidSynthSynthesizer", "struct_fluid_synth_synthesizer.html", null ],
    [ "Libraries::FluidSynth::FluidSynthSynthesizer", "struct_libraries_1_1_fluid_synth_1_1_fluid_synth_synthesizer.html", null ],
    [ "GenericList", null, [
      [ "Audio::AudioDataPointFifoQueueVector", "struct_audio_1_1_audio_data_point_fifo_queue_vector.html", null ],
      [ "Audio::AudioDataPointList", "struct_audio_1_1_audio_data_point_list.html", null ],
      [ "Audio::AudioDataPointListVector", "struct_audio_1_1_audio_data_point_list_vector.html", null ],
      [ "BaseModules::CommandLineArgumentList", "struct_base_modules_1_1_command_line_argument_list.html", null ],
      [ "BaseTypes::Containers::ByteList", "struct_base_types_1_1_containers_1_1_byte_list.html", null ],
      [ "BaseTypes::Containers::IntegerList", "struct_base_types_1_1_containers_1_1_integer_list.html", null ],
      [ "BaseTypes::Containers::NaturalList", "struct_base_types_1_1_containers_1_1_natural_list.html", null ],
      [ "BaseTypes::Containers::RealList", "struct_base_types_1_1_containers_1_1_real_list.html", null ],
      [ "BaseTypes::Containers::StringList", "struct_base_types_1_1_containers_1_1_string_list.html", null ],
      [ "MIDI::MidiEventList", "struct_m_i_d_i_1_1_midi_event_list.html", null ]
    ] ],
    [ "GenericMap", null, [
      [ "BaseTypes::Containers::Dictionary", "struct_base_types_1_1_containers_1_1_dictionary.html", null ]
    ] ],
    [ "GenericNumber", null, [
      [ "BaseTypes::Primitives::Byte", "struct_base_types_1_1_primitives_1_1_byte.html", null ],
      [ "BaseTypes::Primitives::Character", "struct_base_types_1_1_primitives_1_1_character.html", null ],
      [ "BaseTypes::Primitives::Integer", "struct_base_types_1_1_primitives_1_1_integer.html", null ],
      [ "BaseTypes::Primitives::Natural", "struct_base_types_1_1_primitives_1_1_natural.html", null ],
      [ "BaseTypes::Primitives::Real", "struct_base_types_1_1_primitives_1_1_real.html", [
        [ "BaseTypes::Primitives::Percentage", "struct_base_types_1_1_primitives_1_1_percentage.html", null ],
        [ "BaseTypes::Primitives::Radians", "struct_base_types_1_1_primitives_1_1_radians.html", null ]
      ] ]
    ] ],
    [ "GenericSet", null, [
      [ "BaseTypes::Containers::NaturalSet", "struct_base_types_1_1_containers_1_1_natural_set.html", null ]
    ] ],
    [ "juce::ListBoxModel", null, [
      [ "Main::FluidSynthPlugin::_StringListBoxModel", "struct_main_1_1_fluid_synth_plugin_1_1___string_list_box_model.html", null ]
    ] ],
    [ "juce::Button::Listener", null, [
      [ "Main::FluidSynthPlugin::_PresetSelectionComponent", "struct_main_1_1_fluid_synth_plugin_1_1___preset_selection_component.html", null ],
      [ "Main::FluidSynthPlugin::_WidgetListener", "struct_main_1_1_fluid_synth_plugin_1_1___widget_listener.html", null ]
    ] ],
    [ "juce::TextEditor::Listener", null, [
      [ "Main::FluidSynthPlugin::_WidgetListener", "struct_main_1_1_fluid_synth_plugin_1_1___widget_listener.html", null ]
    ] ],
    [ "BaseModules::Logging", "struct_base_modules_1_1_logging.html", null ],
    [ "Logging", "struct_logging.html", null ],
    [ "MIDI::MidiEvent", "struct_m_i_d_i_1_1_midi_event.html", null ],
    [ "MidiEvent", "struct_midi_event.html", null ],
    [ "MIDI::MidiEventConverter", "struct_m_i_d_i_1_1_midi_event_converter.html", null ],
    [ "MidiEventConverter", "struct_midi_event_converter.html", null ],
    [ "MIDI::MidiEventKind", "struct_m_i_d_i_1_1_midi_event_kind.html", null ],
    [ "MidiEventKind", "struct_midi_event_kind.html", null ],
    [ "MIDI::MidiFile", "struct_m_i_d_i_1_1_midi_file.html", null ],
    [ "MidiFile", "struct_midi_file.html", null ],
    [ "MIDI::MidiMetaEventKind", "struct_m_i_d_i_1_1_midi_meta_event_kind.html", null ],
    [ "MidiMetaEventKind", "struct_midi_meta_event_kind.html", null ],
    [ "MIDI::MidiPresetIdentification", "struct_m_i_d_i_1_1_midi_preset_identification.html", null ],
    [ "MidiPresetIdentification", "struct_midi_preset_identification.html", null ],
    [ "std::mutex", null, [
      [ "BaseTypes::Primitives::Mutex", "struct_base_types_1_1_primitives_1_1_mutex.html", null ]
    ] ],
    [ "BaseModules::OperatingSystem", "struct_base_modules_1_1_operating_system.html", null ],
    [ "OperatingSystem", "struct_operating_system.html", null ],
    [ "BaseModules::StringUtil", "struct_base_modules_1_1_string_util.html", null ],
    [ "StringUtil", "struct_string_util.html", null ],
    [ "Windows::tagBITMAP", "struct_windows_1_1tag_b_i_t_m_a_p.html", null ],
    [ "Windows::tagBITMAPINFO", "struct_windows_1_1tag_b_i_t_m_a_p_i_n_f_o.html", null ],
    [ "Windows::tagBITMAPINFOHEADER", "struct_windows_1_1tag_b_i_t_m_a_p_i_n_f_o_h_e_a_d_e_r.html", null ],
    [ "Windows::tagDRAWTEXTPARAMS", "struct_windows_1_1tag_d_r_a_w_t_e_x_t_p_a_r_a_m_s.html", null ],
    [ "Windows::tagLOGFONTW", "struct_windows_1_1tag_l_o_g_f_o_n_t_w.html", null ],
    [ "Windows::tagMSG", "struct_windows_1_1tag_m_s_g.html", null ],
    [ "Windows::tagPAINTSTRUCT", "struct_windows_1_1tag_p_a_i_n_t_s_t_r_u_c_t.html", null ],
    [ "Windows::tagPOINT", "struct_windows_1_1tag_p_o_i_n_t.html", null ],
    [ "Windows::tagRECT", "struct_windows_1_1tag_r_e_c_t.html", null ],
    [ "Windows::tagRGBQUAD", "struct_windows_1_1tag_r_g_b_q_u_a_d.html", null ],
    [ "Windows::tagWNDCLASSEXW", "struct_windows_1_1tag_w_n_d_c_l_a_s_s_e_x_w.html", null ],
    [ "juce::TextEditor", null, [
      [ "Main::FluidSynthPlugin::_TextWidget", "struct_main_1_1_fluid_synth_plugin_1_1___text_widget.html", null ]
    ] ],
    [ "Audio::WaveFile", "struct_audio_1_1_wave_file.html", null ],
    [ "WaveFile", "struct_wave_file.html", null ]
];