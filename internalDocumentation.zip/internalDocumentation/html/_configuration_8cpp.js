var _configuration_8cpp =
[
    [ "Configuration", "struct_configuration.html", "struct_configuration" ]
];