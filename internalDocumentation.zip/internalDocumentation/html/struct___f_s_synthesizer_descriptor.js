var struct___f_s_synthesizer_descriptor =
[
    [ "_FSSynthesizerDescriptor", "struct___f_s_synthesizer_descriptor.html#ab51de98f368f9bad8bfb767768786b9e", null ],
    [ "~_FSSynthesizerDescriptor", "struct___f_s_synthesizer_descriptor.html#ace8d5e61b1afc20de6a89bf4f33b7842", null ],
    [ "associatedLibrary", "struct___f_s_synthesizer_descriptor.html#ae7e764f4b001a333e0769211ccee29d6", null ],
    [ "synthesizer", "struct___f_s_synthesizer_descriptor.html#ab5fb833175b51ac086f81e46cb4f0250", null ],
    [ "synthesizerAudioChannelPairCount", "struct___f_s_synthesizer_descriptor.html#a0808321fc80f486dcff2af886a4aa335", null ],
    [ "synthesizerDestroy", "struct___f_s_synthesizer_descriptor.html#acac6f9975d855498ab6c5bbb450c633e", null ],
    [ "synthesizerHandleBankChange", "struct___f_s_synthesizer_descriptor.html#a2ffaa7ff316ecb61d0fd60b0a7de4102", null ],
    [ "synthesizerHandleChannelPressure", "struct___f_s_synthesizer_descriptor.html#affc2397e10d0c62073711118baca4ab7", null ],
    [ "synthesizerHandleControlChange", "struct___f_s_synthesizer_descriptor.html#aa18b47e302cf5f697546d95f6c384dd0", null ],
    [ "synthesizerHandleNoteOff", "struct___f_s_synthesizer_descriptor.html#ab055abfaf8dff7b332105eab16628c74", null ],
    [ "synthesizerHandleNoteOn", "struct___f_s_synthesizer_descriptor.html#a91238f71f7c9e044e96c1e049d86e2d0", null ],
    [ "synthesizerHandlePitchBend", "struct___f_s_synthesizer_descriptor.html#a7017fae9a1916761f2c399c1dc2a4085", null ],
    [ "synthesizerHandlePolyphonicPressure", "struct___f_s_synthesizer_descriptor.html#a37dd9c252a71a2ceb1c287cf109de734", null ],
    [ "synthesizerHandleProgramChange", "struct___f_s_synthesizer_descriptor.html#a079282e74ad8d7685fca32cba35180ae", null ],
    [ "synthesizerInternalBufferSize", "struct___f_s_synthesizer_descriptor.html#a6cf9b399d23ad828a20e06169e3bf481", null ],
    [ "synthesizerLoadSoundFont", "struct___f_s_synthesizer_descriptor.html#a6f76511fe2e04251bfcf0a99a96f87da", null ],
    [ "synthesizerMake", "struct___f_s_synthesizer_descriptor.html#a2f7d57027073cdce48178a776497b8eb", null ],
    [ "synthesizerProcess", "struct___f_s_synthesizer_descriptor.html#aea8f37f8197f0365befcdfd7444f7dc8", null ],
    [ "synthesizerSetInterpolationMethod", "struct___f_s_synthesizer_descriptor.html#a8225fc9a04c1566d942bfdb93b8ea45c", null ]
];